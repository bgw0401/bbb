package com.scit.web01;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@Controller
public class threeController {
	
	@RequestMapping(value = "/three", method = RequestMethod.GET)
	public String three() {
		
		
		return "three";
	}

}
